public class Main {
	public static void main(String[] args) {
		// Main initialises Jugs, which then runs everything else.
		Jugs j = new Jugs();
	}
}
