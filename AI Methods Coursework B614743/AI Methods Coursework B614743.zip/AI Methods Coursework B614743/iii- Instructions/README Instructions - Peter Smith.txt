Navigate to the AI Methods Coursework B614743/ii- Executable Code/ directory using the Command Prompt.
Type 'java Main' and press Enter.
Follow the onscreen instructions (enter the three jug capacities).